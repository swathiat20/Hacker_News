import React, { Component } from 'react'
import '../styles/app.css'
import News from './News'
import Loader from "react-loader-spinner";

class App extends Component {
  state = {
    stories: [],
    isLoaded: false
  }

  componentDidMount() {
  const hackerStories = 'https://hacker-news.firebaseio.com/v0/topstories.json'
  const hackerUrl = 'https://hacker-news.firebaseio.com/v0/item/'

  fetch(hackerStories)
    .then(checkStatus)
    .then(data => data.json())
    .then(data => data.map(id => {
      const url = `${hackerUrl}${id}.json`
      return fetch(url).then(d => d.json())
    }))
    .then(promises => Promise.all(promises))
    .then(stories => this.setState({stories, isLoaded: true}))
  }

  render() {
    const { stories, isLoaded } = this.state
    return (
      <section>
        { isLoaded ? (
          <News
            stories={stories}
          />
        ) : (
          <div className="container loader">
            <p>Loading top stories...</p>
            <Loader
              type="Puff"
              color="#00BFFF"
              height={100}
              width={100}
            />
          </div>
        ) }
      </section>
    )
  }
}

export default App

export function checkStatus(response) {
  if (response.status === 200) {
    return Promise.resolve(response)
  } else {
    return Promise.reject(
      new Error(response.statusText))
  }
}

