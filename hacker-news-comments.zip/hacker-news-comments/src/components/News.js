import React from 'react'
import '../styles/app.css'
import PropTypes from 'prop-types'

const News = (props) => (
  <div className="container-news">
    <h2 className="text-center">Top News and Comments</h2>
    {props.stories.slice(0,10).map((story , i) =>
      <article key={story.id}>
        <div className="story-header">
          <div className="story-score">
            <p>{story.score}</p>
          </div>
          <div className="story-title">
            <a href={story.url}>
              <b>{story.title}</b>
            </a>
            <p>by <i>{story.by}</i></p>
          </div>
        </div>
        <p>{TEXT_PLACEHOLDER}</p>
      </article>
    )}
  </div>
)

News.propTypes = {
  stories: PropTypes.array.isRequired
}

export default News

export const TEXT_PLACEHOLDER = 'The default spinner uses currentColor for its border-color, meaning you can customize the color with text color utilities .'

